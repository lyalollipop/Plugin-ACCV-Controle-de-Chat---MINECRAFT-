package com.meuplugin.agechat;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class AgeChat extends JavaPlugin implements Listener, CommandExecutor {

    private final Set<UUID> moderators = new HashSet<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        getServer().getPluginManager().registerEvents(this, this);
        
        getCommand("addtext").setExecutor(this);
        getCommand("helpmodgeral").setExecutor(this);
        
        getLogger().info("AgeChat 1.20.1 ativado!");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        
        if (cmd.getName().equalsIgnoreCase("addtext")) {
            if (!sender.hasPermission("agechat.admin")) {
                sender.sendMessage(ChatColor.RED + "Você não tem permissão.");
                return true;
            }

            if (args.length < 2) {
                sender.sendMessage(ChatColor.RED + "Use: /addtext <player> <idade>");
                return true;
            }

            Player target = Bukkit.getPlayer(args[0]);
            if (target == null) {
                sender.sendMessage(ChatColor.RED + "Jogador não encontrado ou offline.");
                return true;
            }

            try {
                int age = Integer.parseInt(args[1]);
                getConfig().set("players." + target.getUniqueId(), age);
                saveConfig();

                sender.sendMessage(ChatColor.GREEN + "Jogador " + target.getName() + " registrado com " + age + " anos.");
                target.sendMessage(ChatColor.AQUA + "Seu chat foi liberado! Categoria: " + age + " anos.");
            } catch (NumberFormatException e) {
                sender.sendMessage(ChatColor.RED + "A idade deve ser um número inteiro.");
            }
            return true;
        }

        if (cmd.getName().equalsIgnoreCase("helpmodgeral")) {
            if (!sender.hasPermission("agechat.admin")) return true;
            if (args.length < 1) return false;

            Player target = Bukkit.getPlayer(args[0]);
            if (target == null) return true;

            UUID uuid = target.getUniqueId();
            if (moderators.contains(uuid)) {
                moderators.remove(uuid);
                sender.sendMessage(ChatColor.YELLOW + "Modo espião DESATIVADO para " + target.getName());
            } else {
                moderators.add(uuid);
                sender.sendMessage(ChatColor.AQUA + "Modo espião ATIVADO para " + target.getName());
            }
            return true;
        }
        return false;
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onChat(AsyncPlayerChatEvent event) {
        Player sender = event.getPlayer();
        String path = "players." + sender.getUniqueId();

        // 1. Bloqueio de quem não tem idade registrada
        if (!getConfig().contains(path)) {
            event.setCancelled(true);
            sender.sendMessage(ChatColor.RED + "Chat bloqueado. É necessário registro de idade por um ADM.");
            return;
        }

        int senderAge = getConfig().getInt(path);
        String prefix = getBracketPrefix(senderAge);
        
        // Mantém o formato original do servidor (essencial para compatibilidade com outros plugins)
        String formattedMessage = String.format(event.getFormat(), sender.getDisplayName(), event.getMessage());

        // 2. Limpa os destinatários para filtragem manual
        event.getRecipients().clear();

        for (Player recipient : Bukkit.getOnlinePlayers()) {
            UUID recUUID = recipient.getUniqueId();

            // Caso 1: Moderador no modo espião (vê tudo com prefixo)
            if (moderators.contains(recUUID)) {
                recipient.sendMessage(prefix + " " + formattedMessage);
                continue;
            }

            // Caso 2: Jogadores na mesma faixa (vêem a mensagem normal)
            String recPath = "players." + recUUID;
            if (getConfig().contains(recPath)) {
                int recAge = getConfig().getInt(recPath);
                if (isSameBracket(senderAge, recAge)) {
                    recipient.sendMessage(formattedMessage);
                }
            }
        }
        
        // Cancela o evento final para evitar que a mensagem original "escape"
        event.setCancelled(true);
    }

    private String getBracketPrefix(int age) {
        if (age >= 18) return ChatColor.DARK_RED + "[18+]";
        if (age >= 16) return ChatColor.GOLD + "[16+]";
        if (age >= 13) return ChatColor.YELLOW + "[13+]";
        return ChatColor.GREEN + "[10+]";
    }

    private boolean isSameBracket(int age1, int age2) {
        if (age1 >= 18 && age2 >= 18) return true;
        if (age1 >= 16 && age1 < 18 && age2 >= 16 && age2 < 18) return true;
        if (age1 >= 13 && age1 < 16 && age2 >= 13 && age2 < 16) return true;
        if (age1 >= 10 && age1 < 13 && age2 >= 10 && age2 < 13) return true;
        return false;
    }
}