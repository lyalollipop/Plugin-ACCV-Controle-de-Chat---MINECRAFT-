package com.meuplugin.agechat;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class AgeChat extends JavaPlugin implements Listener {

    private final Set<UUID> moderators = new HashSet<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("AgeChat 1.8.8 carregado com sucesso!");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        
        // /addtext <player> <idade>
        if (cmd.getName().equalsIgnoreCase("addtext")) {
            if (!sender.hasPermission("agechat.admin")) {
                sender.sendMessage(ChatColor.RED + "Sem permissão!");
                return true;
            }
            if (args.length < 2) {
                sender.sendMessage(ChatColor.RED + "Use: /addtext <player> <idade>");
                return true;
            }

            Player target = Bukkit.getPlayer(args[0]);
            if (target == null) {
                sender.sendMessage(ChatColor.RED + "Jogador offline ou não encontrado.");
                return true;
            }

            try {
                int age = Integer.parseInt(args[1]);
                // Salvando pelo UUID para maior segurança na 1.8.8
                getConfig().set("players." + target.getUniqueId().toString(), age);
                saveConfig();
                
                sender.sendMessage(ChatColor.GREEN + "Jogador " + target.getName() + " definido com " + age + " anos.");
                target.sendMessage(ChatColor.GREEN + "Seu chat foi liberado! Idade registrada: " + age);
            } catch (NumberFormatException e) {
                sender.sendMessage(ChatColor.RED + "A idade precisa ser um número inteiro.");
            }
            return true;
        }

        // /helpmodgeral <player>
        if (cmd.getName().equalsIgnoreCase("helpmodgeral")) {
            if (!sender.hasPermission("agechat.admin")) return true;
            if (args.length < 1) return false;

            Player target = Bukkit.getPlayer(args[0]);
            if (target == null) return true;

            UUID targetUUID = target.getUniqueId();
            if (moderators.contains(targetUUID)) {
                moderators.remove(targetUUID);
                sender.sendMessage(ChatColor.YELLOW + "Modo espião DESATIVADO para " + target.getName());
            } else {
                moderators.add(targetUUID);
                sender.sendMessage(ChatColor.AQUA + "Modo espião ATIVADO para " + target.getName());
            }
            return true;
        }
        return false;
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPlayerChat(AsyncPlayerChatEvent event) {
        Player sender = event.getPlayer();
        String path = "players." + sender.getUniqueId().toString();

        // Se não estiver no config, bloqueia
        if (!getConfig().contains(path)) {
            event.setCancelled(true);
            sender.sendMessage(ChatColor.RED + "Seu chat está bloqueado. Peça para um Staff usar /addtext.");
            return;
        }

        int senderAge = getConfig().getInt(path);
        String prefix = getBracketPrefix(senderAge);
        String messageFormat = ChatColor.WHITE + "<" + sender.getDisplayName() + "> " + event.getMessage();

        // Limpa destinatários padrão
        event.getRecipients().clear();

        for (Player recipient : Bukkit.getOnlinePlayers()) {
            UUID recUUID = recipient.getUniqueId();
            
            // 1. Staff em modo espião (vê tudo com prefixo da idade do autor)
            if (moderators.contains(recUUID)) {
                recipient.sendMessage(prefix + " " + messageFormat);
                continue;
            }

            // 2. Jogadores comuns (vêem apenas sua própria faixa, sem prefixo)
            String recPath = "players." + recUUID.toString();
            if (getConfig().contains(recPath)) {
                int recAge = getConfig().getInt(recPath);
                if (isSameBracket(senderAge, recAge)) {
                    recipient.sendMessage(messageFormat);
                }
            }
        }
        
        // Cancela o evento original para evitar duplicatas
        event.setCancelled(true);
    }

    private String getBracketPrefix(int age) {
        if (age >= 18) return ChatColor.DARK_RED + "[18+]";
        if (age >= 16) return ChatColor.GOLD + "[16+]";
        if (age >= 13) return ChatColor.YELLOW + "[13+]";
        return ChatColor.GREEN + "[10+]";
    }

    private boolean isSameBracket(int age1, int age2) {
        if (age1 >= 18 && age2 >= 18) return true;
        if (age1 >= 16 && age1 < 18 && age2 >= 16 && age2 < 18) return true;
        if (age1 >= 13 && age1 < 16 && age2 >= 13 && age2 < 16) return true;
        if (age1 >= 10 && age1 < 13 && age2 >= 10 && age2 < 13) return true;
        return false;
    }
}