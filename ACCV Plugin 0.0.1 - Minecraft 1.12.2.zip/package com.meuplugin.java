package com.meuplugin.agechat;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerChatEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public class AgeChat extends JavaPlugin implements Listener {

    private final Set<UUID> moderators = new HashSet<>();

    @Override
    public void onEnable() {
        saveDefaultConfig();
        getServer().getPluginManager().registerEvents(this, this);
        getLogger().info("AgeChat 1.12.2 inicializado!");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        
        if (cmd.getName().equalsIgnoreCase("addtext")) {
            if (!sender.hasPermission("agechat.admin")) {
                sender.sendMessage(ChatColor.RED + "Você não tem permissão para isso.");
                return true;
            }

            if (args.length < 2) {
                sender.sendMessage(ChatColor.RED + "Uso correto: /addtext <player> <idade>");
                return true;
            }

            Player target = Bukkit.getPlayer(args[0]);
            if (target == null) {
                sender.sendMessage(ChatColor.RED + "Jogador não encontrado.");
                return true;
            }

            try {
                int age = Integer.parseInt(args[1]);
                // Salva no config.yml usando o UUID
                getConfig().set("players." + target.getUniqueId().toString(), age);
                saveConfig();

                sender.sendMessage(ChatColor.GREEN + "Sucesso! " + target.getName() + " agora tem " + age + " anos.");
                target.sendMessage(ChatColor.AQUA + "Seu chat foi liberado por um administrador.");
            } catch (NumberFormatException e) {
                sender.sendMessage(ChatColor.RED + "A idade precisa ser um número.");
            }
            return true;
        }

        if (cmd.getName().equalsIgnoreCase("helpmodgeral")) {
            if (!sender.hasPermission("agechat.admin")) return true;